const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_PATH = path.join(ROOT, "data.json");
const PUBLIC_HTML = path.join(ROOT, "index.html");

const sessions = new Map();       // token -> { accountId, expiresAt }
const streams = new Set();        // SSE response objects

function ensureData(){
  if(!fs.existsSync(DATA_PATH)){
    fs.writeFileSync(DATA_PATH, JSON.stringify({accounts:[],chat:[],meta:{version:1}}, null, 2));
  }
  try{
    const d = JSON.parse(fs.readFileSync(DATA_PATH,"utf8"));
    if(!Array.isArray(d.accounts)) d.accounts = [];
    if(!Array.isArray(d.chat)) d.chat = [];
    if(!d.meta) d.meta = {version:1};
    return d;
  }catch(e){
    return {accounts:[],chat:[],meta:{version:1}};
  }
}
function saveData(data){
  data.meta = Object.assign({}, data.meta, {version:1, updatedAt:new Date().toISOString()});
  const tmp = DATA_PATH + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
  fs.renameSync(tmp, DATA_PATH);
}
function cleanAccount(a){
  const { passwordHash, passwordSalt, ...safe } = a || {};
  return safe;
}
function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")){
  const hash = crypto.scryptSync(String(password), salt, 64).toString("hex");
  return {hash, salt};
}
function verifyPassword(password, account){
  if(!account?.passwordHash || !account?.passwordSalt) return false;
  const {hash} = hashPassword(password, account.passwordSalt);
  return crypto.timingSafeEqual(Buffer.from(hash,"hex"), Buffer.from(account.passwordHash,"hex"));
}
function token(){
  return crypto.randomBytes(32).toString("hex");
}
function accountId(){
  return "MODY-" + Date.now().toString(36).toUpperCase() + "-" + crypto.randomBytes(3).toString("hex").toUpperCase();
}
function getToken(req, urlObj){
  const auth = req.headers.authorization || "";
  if(auth.startsWith("Bearer ")) return auth.slice(7);
  return urlObj.searchParams.get("token") || "";
}
function authAccount(req, urlObj, data){
  const t = getToken(req,urlObj);
  const s = sessions.get(t);
  if(!s || s.expiresAt < Date.now()){ if(t) sessions.delete(t); return null; }
  return data.accounts.find(a => a.id === s.accountId) || null;
}
function sendJson(res, code, obj){
  const body = JSON.stringify(obj);
  res.writeHead(code, {"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store","Access-Control-Allow-Origin":"*"});
  res.end(body);
}
function parseBody(req){
  return new Promise((resolve,reject)=>{
    let raw="", size=0;
    req.on("data",chunk=>{
      size += chunk.length;
      if(size > 3_000_000){ reject(new Error("Payload too large")); req.destroy(); return; }
      raw += chunk;
    });
    req.on("end",()=>{ try{resolve(raw?JSON.parse(raw):{});}catch(e){reject(new Error("Invalid JSON"));} });
    req.on("error",reject);
  });
}
function validEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v||"")); }
function validUsername(v){ return /^[\p{L}\p{N}_ .-]{2,30}$/u.test(String(v||"").trim()); }
function validPlayerId(v){ return /^\d{4,20}$/.test(String(v||"")); }

function broadcastChat(message){
  const payload = "data: " + JSON.stringify(message) + "\n\n";
  for(const res of streams){
    try{ res.write(payload); }catch(e){ streams.delete(res); }
  }
}

async function route(req,res){
  const urlObj = new URL(req.url, "http://localhost");
  const pathname = urlObj.pathname;
  const data = ensureData();

  if(req.method === "OPTIONS"){
    res.writeHead(204, {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET,POST,OPTIONS","Access-Control-Allow-Headers":"Content-Type, Authorization"});
    return res.end();
  }

  if(pathname === "/api/register" && req.method === "POST"){
    let b; try{b=await parseBody(req);}catch(e){return sendJson(res,400,{error:e.message});}
    const username=String(b.username||"").trim(), playerId=String(b.playerId||"").trim();
    const email=String(b.email||"").trim().toLowerCase(), password=String(b.password||"");
    const avatar=String(b.avatar||"");
    if(!validUsername(username)) return sendJson(res,400,{error:"اسم المستخدم غير صالح."});
    if(!validPlayerId(playerId)) return sendJson(res,400,{error:"Free Fire ID غير صالح."});
    if(!validEmail(email)) return sendJson(res,400,{error:"البريد الإلكتروني غير صالح."});
    if(password.length<6 || password.length>200) return sendJson(res,400,{error:"كلمة المرور يجب أن تكون بين 6 و200 حرف."});
    if(avatar.length > 2_200_000) return sendJson(res,400,{error:"الصورة كبيرة جدًا."});
    if(data.accounts.some(a=>String(a.email).toLowerCase()===email)) return sendJson(res,409,{error:"البريد الإلكتروني مستخدم بالفعل."});
    if(data.accounts.some(a=>String(a.playerId)===playerId)) return sendJson(res,409,{error:"Free Fire ID مستخدم بالفعل."});
    const hp=hashPassword(password);
    const account={id:accountId(),username,playerId,email,avatar,createdAt:new Date().toISOString(),blackList:playerId==="2149137612"};
    account.passwordHash=hp.hash; account.passwordSalt=hp.salt;
    data.accounts.push(account); saveData(data);
    const t=token(); sessions.set(t,{accountId:account.id,expiresAt:Date.now()+1000*60*60*24*30});
    return sendJson(res,201,{token:t,account:cleanAccount(account)});
  }

  if(pathname === "/api/login" && req.method === "POST"){
    let b; try{b=await parseBody(req);}catch(e){return sendJson(res,400,{error:e.message});}
    const email=String(b.email||"").trim().toLowerCase(), password=String(b.password||"");
    const account=data.accounts.find(a=>String(a.email).toLowerCase()===email);
    if(!account || !verifyPassword(password,account)) return sendJson(res,401,{error:"البريد الإلكتروني أو كلمة المرور غير صحيحة."});
    const t=token(); sessions.set(t,{accountId:account.id,expiresAt:Date.now()+1000*60*60*24*30});
    return sendJson(res,200,{token:t,account:cleanAccount(account)});
  }

  if(pathname === "/api/logout" && req.method === "POST"){
    const t=getToken(req,urlObj); if(t) sessions.delete(t);
    return sendJson(res,200,{ok:true});
  }

  if(pathname === "/api/me" && req.method === "GET"){
    const a=authAccount(req,urlObj,data);
    if(!a) return sendJson(res,401,{error:"غير مسجل الدخول."});
    return sendJson(res,200,{account:cleanAccount(a)});
  }

  if(pathname === "/api/players" && req.method === "GET"){
    const accounts=data.accounts.map(cleanAccount).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
    return sendJson(res,200,{accounts});
  }

  if(pathname === "/api/chat/messages" && req.method === "GET"){
    const a=authAccount(req,urlObj,data);
    if(!a) return sendJson(res,401,{error:"سجل الدخول أولًا."});
    return sendJson(res,200,{messages:data.chat.slice(-200)});
  }

  if(pathname === "/api/chat/messages" && req.method === "POST"){
    const a=authAccount(req,urlObj,data);
    if(!a) return sendJson(res,401,{error:"سجل الدخول أولًا."});
    let b; try{b=await parseBody(req);}catch(e){return sendJson(res,400,{error:e.message});}
    const text=String(b.text||"").trim();
    if(!text) return sendJson(res,400,{error:"الرسالة فارغة."});
    if(text.length>300) return sendJson(res,400,{error:"الرسالة طويلة جدًا."});
    const message={id:crypto.randomUUID(),accountId:a.id,username:a.username,text,createdAt:new Date().toISOString()};
    data.chat.push(message); data.chat=data.chat.slice(-500); saveData(data);
    broadcastChat(message);
    return sendJson(res,201,{message});
  }

  if(pathname === "/api/chat/stream" && req.method === "GET"){
    const a=authAccount(req,urlObj,data);
    if(!a){res.writeHead(401,{"Content-Type":"text/plain"});return res.end("Unauthorized");}
    res.writeHead(200,{"Content-Type":"text/event-stream; charset=utf-8","Cache-Control":"no-cache","Connection":"keep-alive","Access-Control-Allow-Origin":"*"});
    res.write("retry: 3000\n\n");
    streams.add(res);
    const ping=setInterval(()=>{try{res.write(": ping\n\n");}catch(e){}},15000);
    req.on("close",()=>{clearInterval(ping);streams.delete(res);});
    return;
  }

  if(pathname === "/" || pathname === "/index.html"){
    const body=fs.readFileSync(PUBLIC_HTML);
    res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store"});
    return res.end(body);
  }

  if(pathname === "/data.json"){
    // Do not expose passwords/salts to the browser.
    return sendJson(res,403,{error:"data.json is server-only."});
  }

  res.writeHead(404,{"Content-Type":"text/plain; charset=utf-8"});
  res.end("Not found");
}

setInterval(()=>{
  const now=Date.now();
  for(const [t,s] of sessions) if(s.expiresAt<now) sessions.delete(t);
}, 60_000);

ensureData();
http.createServer((req,res)=>route(req,res).catch(e=>{
  console.error(e);
  if(!res.headersSent) sendJson(res,500,{error:"Internal server error"});
  else res.end();
})).listen(PORT,()=>console.log(`MODY PANEL live server: http://localhost:${PORT}`));
